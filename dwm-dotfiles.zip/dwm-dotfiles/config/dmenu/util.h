/* See LICENSE file for copyright and license details. */

#define MAX(A, B)               ((A) > (B) ? (A) : (B))
#define MIN(A, B)               ((A) < (B) ? (A) : (B))
#define BETWEEN(X, A, B)        ((A) <= (X) && (X) <= (B))

#if defined(__GNUC__) || defined(__clang__)
__attribute__((noreturn, format(printf, 1, 2), nonnull(1)))
#endif
void die(const char *fmt, ...);
void *ecalloc(size_t nmemb, size_t size);
