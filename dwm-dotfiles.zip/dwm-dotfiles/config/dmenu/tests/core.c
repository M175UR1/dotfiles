/* Exercise the patched static functions without requiring an X server. */
#define main dmenu_main
#include "../dmenu.c"
#undef main
#include <assert.h>

static void
test_resources(void)
{
	XrmDatabase db;
	char *value = "default";
	ResourcePref pref = { "prompt", &value };
	char resource[4096];

	XrmInitialize();
	db = XrmGetStringDatabase("dmenu.normfgcolor: white\n");
	resource_load(db, &pref);
	assert(!strcmp(value, "default"));
	XrmDestroyDatabase(db);
	strcpy(resource, "dmenu.prompt: ");
	memset(resource + strlen(resource), 'x', 3000);
	resource[3014] = '\n';
	resource[3015] = '\0';
	db = XrmGetStringDatabase(resource);
	resource_load(db, &pref);
	assert(strlen(value) == 3000);
	XrmDestroyDatabase(db);
	pref.name = "normfgcolor";
	db = XrmGetStringDatabase("dmenu.normfgcolor: LightGoldenrodYellow\n");
	resource_load(db, &pref);
	assert(!strcmp(value, "LightGoldenrodYellow"));
	XrmDestroyDatabase(db);
}

static void
test_matching(void)
{
	struct item sample[] = {
		{ .text = "alpha" }, { .text = "alphabet" },
		{ .text = "Beta" }, { .text = "far apart" }, { .text = NULL }
	};
	struct item *it;
	int count;

	items = sample;
	mw = 800;
	bh = 20;
	strcpy(text, "alpha");
	match();
	assert(matches && matches->right && !matches->right->right);
	strcpy(text, "bet");
	match();
	assert(sel == &sample[2]);
	strcpy(text, "faap");
	match();
	assert(matches == &sample[3] && matchend == matches);
	strcpy(text, "missing");
	match();
	assert(!matches && !curr && !next);
	text[0] = '\0';
	match();
	for (count = 0, it = matches; it; it = it->right)
		count++;
	assert(count == 4);
	fuzzy = 0;
	strcpy(text, "apart far");
	match();
	assert(matches == &sample[3]);
	fuzzy = 1;
	items = NULL;
	text[0] = '\0';
	cursor = 0;
	match();
}

static void
test_editing(void)
{
	insert("alpha beta", 10);
	cursor = 5;
	insert(NULL, -5);
	assert(!strcmp(text, " beta") && cursor == 0);
	insert(NULL, -1); /* deleting before the input must be rejected */
	assert(!strcmp(text, " beta"));
	insert("new", 3);
	assert(!strcmp(text, "new beta") && cursor == 3);
	insert("x", sizeof text); /* reject oversized paste */
	assert(!strcmp(text, "new beta"));
	strcpy(text, "a\303\251b");
	cursor = 3;
	assert(nextrune(-1) == 1 && nextrune(1) == 4);
	assert(textw_clamp("test", -10) == 0);
	assert(parse_lines("0") == 0 && parse_lines("20") == 20);
}

int
main(void)
{
	test_resources();
	test_matching();
	test_editing();
	puts("core regression tests passed");
	return 0;
}
