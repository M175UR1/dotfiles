import os
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent.parent


def run(args, env=None, **kwargs):
    return subprocess.run(args, env=env, text=True, capture_output=True, **kwargs)


no_display = {**os.environ, "DISPLAY": ""}
p = run([str(ROOT / "dmenu"), "-v"], no_display)
assert p.returncode == 0 and p.stdout.strip() == "dmenu-5.2", p
p = run([str(ROOT / "dmenu")], no_display, input="")
assert p.returncode == 1 and "cannot open display" in p.stderr, p

with tempfile.TemporaryDirectory(prefix="dmenu-test-") as tmp:
    tmp = Path(tmp)
    bins = tmp / "helpers"
    bins.mkdir()
    for name, target in [("stest", ROOT / "stest"), ("sort", "/usr/bin/sort")]:
        (bins / name).symlink_to(target)
    first, second = tmp / "first [literal]", tmp / "second"
    first.mkdir()
    second.mkdir()

    def executable(path, body="#!/bin/sh\nexit 0\n"):
        path.write_text(body)
        path.chmod(0o755)

    executable(first / "first-app")
    executable(second / "second-app")
    executable(tmp / "current-app")
    env = {**os.environ, "PATH": f"{bins}:{first}", "XDG_CACHE_HOME": str(tmp / "cache")}
    p = run([str(ROOT / "dmenu_path")], env, cwd=tmp)
    assert p.returncode == 0 and "first-app" in p.stdout.splitlines(), p
    env["PATH"] = f"{bins}:{second}:"
    p = run([str(ROOT / "dmenu_path")], env, cwd=tmp)
    assert "first-app" not in p.stdout.splitlines(), p
    assert {"second-app", "current-app"} <= set(p.stdout.splitlines()), p
    (second / "second-app").chmod(0o644)
    assert "second-app" not in run([str(ROOT / "dmenu_path")], env, cwd=tmp).stdout.splitlines()

    executable(bins / "dmenu_run", '#!/bin/sh\nprintf "%s\\n" "$@"\n')
    p = run([str(ROOT / "dmenu-launcher.sh"), "2", "-l", "10"], env)
    assert p.stdout.splitlines() == [
        "-m", "2", "-nb", "#1e1e2e", "-nf", "#cdd6f4",
        "-sb", "#a6e3a1", "-sf", "#11111b", "-nhf", "#cba6f7",
        "-shf", "#11111b", "-l", "10",
    ], p
    executable(bins / "dmenu_path", '#!/bin/sh\nprintf "example\\n"\n')
    executable(bins / "dmenu", "#!/bin/sh\nexit 1\n")
    p = run([str(ROOT / "dmenu_run")], env)
    assert p.returncode == 1, p
    # A shell path containing spaces must remain one argument.
    shell = tmp / "shell with spaces"
    executable(shell, '#!/bin/sh\nwhile IFS= read -r line; do printf "%s\\n" "$line"; done\n')
    executable(bins / "dmenu", '#!/bin/sh\nprintf "echo test\\n"\n')
    env["SHELL"] = str(shell)
    p = run([str(ROOT / "dmenu_run")], env)
    assert p.returncode == 0 and p.stdout == "echo test\n", p

print("CLI and launcher regression tests passed")
