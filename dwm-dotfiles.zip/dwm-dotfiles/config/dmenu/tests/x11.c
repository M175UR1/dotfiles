/* Render in an offscreen parent: no keyboard grab and no desktop focus change. */
#define main dmenu_main
#include "../dmenu.c"
#undef main
#include <assert.h>

int
main(void)
{
	XEvent event = {0};
	char *fixtures[] = { "alpha", "alphabet", "caf\303\251", "far apart" };
	size_t i;

	setlocale(LC_CTYPE, "");
	if (!(dpy = XOpenDisplay(NULL)))
		die("cannot open test display");
	screen = DefaultScreen(dpy);
	root = RootWindow(dpy, screen);
	parentwin = XCreateSimpleWindow(dpy, root, -2000, -2000, 640, 300, 0, 0, 0);
	XMapWindow(dpy, parentwin);
	XrmInitialize();
	load_xresources();
	fonts[0] = font;
	xinitvisual();
	drw = drw_create(dpy, screen, root, 640, 300, visual, depth, cmap);
	assert(drw_fontset_create(drw, fonts, LENGTH(fonts)));
	lrpad = drw->fonts->h;
	items = ecalloc(LENGTH(fixtures) + 1, sizeof *items);
	for (i = 0; i < LENGTH(fixtures); i++)
		items[i].text = strdup(fixtures[i]);
	setup();
	strcpy(text, "alpha");
	cursor = 2;
	match();
	drawmenu();
	assert(matches && matches->right);
	/* Clicking input clears the entire query, including text after the cursor. */
	event.xbutton.window = win;
	event.xbutton.button = Button1;
	event.xbutton.x = 1;
	event.xbutton.y = 1;
	buttonpress(&event);
	assert(!*text && !cursor);
	/* Unicode highlighting and clipped widths must be safe. */
	strcpy(text, "\303\251");
	cursor = strlen(text);
	match();
	assert(sel == &items[2]);
	drawmenu();
	drawhighlights(sel, 0, 0, 1);
	fuzzy = 0;
	strcpy(text, "apart far");
	cursor = strlen(text);
	match();
	drawmenu();
	assert(sel == &items[3]);
	lines = 2;
	match();
	drawmenu();
	/* Tiny layout must not wrap negative dimensions into huge unsigned widths. */
	lines = 0;
	mw = 10;
	inputw = 3;
	promptw = 0;
	match();
	drawmenu();
	XSync(dpy, False);
	cleanup();
	puts("X11 rendering regression tests passed");
	return 0;
}
