/* See LICENSE file for copyright and license details. */
/* Default settings; can be overriden by command line. */

static int topbar = 1;                      /* -b  option; if 0, dmenu appears at bottom     */
static int fuzzy = 1;                      /* -F  option; if 0, dmenu doesn't use fuzzy matching     */
static const unsigned int alpha = 0xF0;
static int centered = 1;                    /* center dmenu on screen by default */
static int min_width = 500;                    /* minimum width when centered */
/* -fn option overrides fonts[0]; default X11 font or font set */
static char *font = "monospace:size=10";
static const char *fonts[] = {
	"monospace:size=10"
};
static char *prompt       = NULL;      /* -p  option; prompt to the left of input field */


static char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#bbbbbb", "#222222" },
	[SchemeSel]  = { "#eeeeee",  "#005577"  },
	[SchemeNormHighlight] = { "#ffc978", "#222222" },
	[SchemeSelHighlight] = { "#ffc978", "#005577" },
	[SchemeOut]  = { "#000000",   "#00ffff" },
};

static const unsigned int alphas[SchemeLast][2] = {
	[SchemeNorm] = { OPAQUE, alpha },
	[SchemeSel] = { OPAQUE, alpha },
	[SchemeSelHighlight] = { OPAQUE, alpha },
	[SchemeNormHighlight] = { OPAQUE, alpha },
	[SchemeOut] = { OPAQUE, alpha },
};

/* -l option; if nonzero, dmenu uses vertical list with given number of lines */
static unsigned int lines      = 10;

/*
 * Characters not considered part of a word while deleting words
 * for example: " /?\"&[]"
 */
static const char worddelimiters[] = " ";

/* Size of the window border */
static const unsigned int border_width = 1;


/*
 * Xresources preferences to load at startup
 */
static const ResourcePref resources[] = {
	{ "font", &font },
	{ "normfgcolor", &colors[SchemeNorm][ColFg] },
	{ "normbgcolor", &colors[SchemeNorm][ColBg] },
	{ "selfgcolor", &colors[SchemeSel][ColFg] },
	{ "selbgcolor", &colors[SchemeSel][ColBg] },
	{ "highlightnormfgcolor", &colors[SchemeNormHighlight][ColFg] },
	{ "highlightnormbgcolor", &colors[SchemeNormHighlight][ColBg] },
	{ "highlightselfgcolor", &colors[SchemeSelHighlight][ColFg] },
	{ "highlightselbgcolor", &colors[SchemeSelHighlight][ColBg] },
	{ "prompt", &prompt },
};
