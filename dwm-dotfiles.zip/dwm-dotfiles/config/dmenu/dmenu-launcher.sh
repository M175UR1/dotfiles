#!/bin/sh
# dwm passes the selected monitor as the first argument.
monitor=${1:-0}
if [ "$#" -gt 0 ]; then
	shift
fi
# deskctl updates the quoted -sb value when the desktop accent changes.
exec dmenu_run -m "$monitor" \
	-nb '#1e1e2e' -nf '#cdd6f4' -sb '#a6e3a1' -sf '#11111b' \
	-nhf '#cba6f7' -shf '#11111b' "$@"
